<?php

$conn = mysqli_connect('localhost','root','','user_db');
echo "<script>console.log('connected succesfully')</script>";

?>