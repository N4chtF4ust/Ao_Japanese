<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Ao_new";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die(echo "<script> console.log('Connection failed: " . $conn->connect_error . "'); </script>");
}
  echo "<script> console.log('Connected successfully'); </script>";
  echo "nigga";
?>

