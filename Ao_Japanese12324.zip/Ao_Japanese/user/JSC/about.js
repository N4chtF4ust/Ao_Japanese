function menu_click(a,b){
    a.classList.toggle("click");
    b.classList.toggle("click");
}

function dropdown(ddown){
    ddown.classList.toggle("click");

}

function quantity_minus(a){
    let x = 0;
    x--;
    console.log(a=x);

}

function toggleCart(cart){
    cart.classList.toggle("click");


}