function menu_click(a,b){
    a.classList.toggle("click");
    b.classList.toggle("click");
}

function dropdown(ddown){
    ddown.classList.toggle("click");

}